jumlah_kategori = int(input("Masukkan Jumlah Kategori: "))
aplikasi_kategori = {}

for indeks in range(jumlah_kategori):
    nama_kategori = input("Masukkan Nama Kategori: ")
    print(f"Masukkan 5 nama aplikasi di kategori {nama_kategori}")
    daftar_aplikasi = []

    for nomor in range(5):
        nama_aplikasi = input("Masukkan Nama Aplikasi: ")
        daftar_aplikasi.append(nama_aplikasi)
    aplikasi_kategori[nama_kategori] = daftar_aplikasi
    
print(aplikasi_kategori)
print()

set_aplikasi = [set(aplikasi) for aplikasi in aplikasi_kategori.values()]
print(set_aplikasi)
print()

unik = set_aplikasi[0]
for i in range(1, jumlah_kategori):
    unik ^= set_aplikasi[i]
print("Aplikasi Yang Hanya Muncul Di Satu Kategori Saja:", unik)
print()

if jumlah_kategori > 2:
    inter = set_aplikasi[0]
    for i in range(1, jumlah_kategori):
        inter &= set_aplikasi[i]
    print("Aplikasi Yang Muncul Di Dua Kategori Sekaligus:", inter)

