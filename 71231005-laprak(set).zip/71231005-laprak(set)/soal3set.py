def baca_file(nama_file):
    try:
        with open(nama_file, 'r') as file:
            isi_file = file.read()
            return isi_file.lower().split()
    except FileNotFoundError:
        print("File tidak ada atau tidak dapat dibaca:", nama_file)
        return []

def kata_yang_muncul_pada_kedua_file(file1, file2):
    kata_file1 = baca_file(file1)
    kata_file2 = baca_file(file2)
    kata_yang_muncul = set(kata_file1) & set(kata_file2)
    return kata_yang_muncul

def main():
    file1 = input("Masukkan nama file teks pertama: ")
    file2 = input("Masukkan nama file teks kedua: ")

    print("\nKata yang muncul pada kedua file:")
    kata_yang_muncul = kata_yang_muncul_pada_kedua_file(file1, file2)
    if kata_yang_muncul:
        for kata in kata_yang_muncul:
            print(kata)
    else:
        print("Tidak ada kata yang muncul pada kedua file.")

if __name__ == "__main__":
    main()

