list_data = ["apel", "pisang", "apel", "jeruk", "mangga"]
print("== List jadi Set ==")
print("Kalimat sebelum konversi:", list_data)
set_data = set(list_data)
print("Kalimat setelah konversi:", set_data)

set_data = {"apel", "pisang", "jeruk", "mangga"}
print("\n== Set jadi List ==")
print("Kalimat sebelum konversi:", set_data)
list_data = list(set_data)
print("Kalimat setelah konversi:", list_data)

tuple_data = ("satu", "dua", "tiga", "empat", "satu")
print("\n== Tuple jadi Set ==")
print("Kalimat sebelum konversi:", tuple_data)
set_data = set(tuple_data)
print("Kalimat setelah konversi:", set_data)

set_data = {"satu", "dua", "tiga", "empat", "lima"}
print("\n== Set jadi Tuple ==")
print("Kalimat sebelum konversi:", set_data)
tuple_data = tuple(set_data)
print("Kalimat setelah konversi:", tuple_data)

